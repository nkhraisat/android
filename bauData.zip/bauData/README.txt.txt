project name : Bau data
project team :
noor aldeen khraisat
mohammad ramadan 
awad aburumman

emails :
noor aldeen : norkres@gmail.com
moammad:mohammadra74@gmail.com
awad : awadaburumman@yahoo.com

team leader : noor aldeen khraisat

project description :
this project for university student 
has a three button 
button for calculate avarege 
button for materials (slides , books , etcs...)
and button about unversity .

and thanks  .

dr : sultan alkhateib 
