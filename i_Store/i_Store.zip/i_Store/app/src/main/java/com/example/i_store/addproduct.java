package com.example.i_store;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class addproduct extends AppCompatActivity {
     FirebaseAuth mAuth;
    FirebaseDatabase database;
    DatabaseReference myRef;
    EditText pname , pmodel,pcolor,pdes;
    Spinner s;
    DatabaseReference ref;
    ArrayList<String> arr;
    ArrayList<String> name;
    String uid;
    int pid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addproduct);
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("database").child("products");
        pname=(EditText)findViewById(R.id.pname);
        pmodel=(EditText)findViewById(R.id.model);
        pcolor=(EditText)findViewById(R.id.pcolor);
        pdes=(EditText)findViewById(R.id.desc);
        mAuth = FirebaseAuth.getInstance();
        uid=getIntent().getStringExtra("nn");
        ArrayList items = new ArrayList();
        items.add( "Cars" );
        items.add( "Fashion" );

        items.add( "Sports" );
        items.add( "Health" );
        items.add( "Books" );
        items.add( "Computers" );
        items.add( "Music" );
        items.add( "Phones" );
        items.add( "Kids" );
        items.add( "Watches" );

         s = (Spinner) findViewById(R.id.sp);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, items);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(adapter);
        ref= FirebaseDatabase.getInstance().getReference().child("database").child("products");
        ref= FirebaseDatabase.getInstance().getReference().child("database").child("products");
        FirebaseDatabase.getInstance().getReference().child("database").child("products").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                    product p =snapshot.getValue(product.class);
                    pid=0;
                    if(Integer.parseInt(p.getId())>=pid)
                        pid=Integer.parseInt(p.getId())+1;


                }
                Toast.makeText(getApplicationContext(),"product id is :"+pid,Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }


    public void add(View view) {
        String name , model, color,des;
        name= pname.getText().toString();
        model=pmodel.getText().toString();
        color=pcolor.getText().toString();
        des=pdes.getText().toString();
        String category= s.getSelectedItem().toString();
        if(name.isEmpty())
        {
            pname.setError("please enter the product name");
        }
        if(model.isEmpty())
        {
            pmodel.setError("please enter the product model");
        }
        if(des.isEmpty())
        {
            pdes.setError("please enter the product descrption");
        }
        if(!name.isEmpty()&&!model.isEmpty()&&!des.isEmpty())
        {

            product p = new product(String.valueOf(pid),uid,category,name, model,color,des);
        Toast.makeText(addproduct.this, "product added successfully",
                Toast.LENGTH_SHORT ).show();
        myRef.push().setValue(p);
            Intent i = new Intent(getApplicationContext(),category.class);
            startActivity(i);
            finish();

    }else
            Toast.makeText(addproduct.this, "please fill all requirments",
                    Toast.LENGTH_SHORT ).show();
    }
}