package com.example.i_store;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class watches extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_watches );
        ListView lv = findViewById( R.id.watcheslistview );
        ArrayList arr = new ArrayList(  );
        arr.add("Rolex");
        arr.add("Patek Philippe");
        arr.add("Audemars Piguet");
        arr.add("Blancpain");
        arr.add("Chopard");
        arr.add("Hublot");

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, arr);
        lv.setAdapter(arrayAdapter);
    }
}
