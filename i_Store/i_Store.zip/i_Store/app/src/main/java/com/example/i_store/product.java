package com.example.i_store;

import android.widget.EditText;

public class product {
    String category , name,model, color,desc,uid;
    String id;
    public product(String id,String uid,String category, String name, String model, String color, String desc) {
        this.category = category;
        this.name = name;
        this.model = model;
        this.color = color;
        this.desc = desc;
        this.id=id;
        this.uid=uid;
    }

    public product() {
    }


    public String getUid() {
        return uid;
    }

    public String getCategory() {
        return category;
    }

    public String getName() {
        return name;
    }

    public String getModel() {
        return model;
    }

    public String getColor() {
        return color;
    }

    public String getDesc() {
        return desc;
    }

    public String getId() {
        return id;
    }
}
